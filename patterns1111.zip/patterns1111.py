for i in range(1,6):
    for j in range(1,6):
        print("*",end=" ")
    print()

for i in range(1,6):
    for j in range(1,6):
        print(i, end=" ")
    print()

for i in range(1,6):
    for j in range(1,6):
        print(j, end=" ")
    print()

for i in range(65,70):
    for j in range(1,6):
        print(chr(i), end=" ")
    print()

for i in range(1,6):
    for j in range(65,70):
        print(chr(j), end=" ")
    print()
for i in range(5,0,-1):
    for j in range(1,6):
        print(i,end=" ")
    print()
for i in range(1,6):
    for j in range(5,0,-1):
        print(j,end=" ")
    print()
for i in range(69,64,-1):
    for j in range(1,6):
        print(chr(i),end=" ")
    print()
for i in range(1,6):
    for j in range(69,64,-1):
        print(chr(j),end=" ")
    print()

for i in range(1,6):
    for j in range(1,i+1):
        print("*",end=" ")
    print()
    
